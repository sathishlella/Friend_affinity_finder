def func(gender,Age,Music,Movies,Internet,Shopping,loneliness):
#_____________________________________________________packages_______________________________________________________________________
        print(gender,Age,Music,Movies,Internet,Shopping,loneliness)



        #______________________________________________data path & arrangment_____________________________________________________________________
        #providing path for the data so that it can access the data from the path.
        #please provide your path.
        path=r"C:\Users\TOSHIBA-PC\Desktop\ibm234 final\ibm234\student_processed_data.csv"
        #path=r"please enter your path.."
        names=("Gender","Age","Music","Movies","Internet","Shopping","Loneliness","Fun with friends")


        #__________________________________________________collecting data___________________________________________________________________
        #linking the names to the data set.

        data=pd.read_csv(path, names=names )
        #print(data.tail())
        print(data.shape)
        #__________________________________________________acess from index_________________________________________________________________
        #Separating the train data and test data.

        X=data.iloc[ :, :7].values
        y=data.iloc[ :,7].values
        #print(y)
        #print(X)

        #______________________________________________corellation and plotting______________________________________________________________________
        """ 
        #plotting the correlation graph.


        correlation=data.corr()
        print(correlation)
        corelation=data.corr()#here corelation 
        fig=plt.figure()
        ax=fig.add_subplot(222)
        cax=ax.matshow(corelation,vmax=1,vmin=-1)
        plt.show()

        #Plotting a histogram

        data.hist()
        plt.show()

        #plotting a scatter graph

        from pandas.plotting import scatter_matrix
        scatter_matrix(data)
        plt.show()
           """ 
        #__________________________________________________model bulding____________________________________________________________________


        from sklearn.model_selection import train_test_split
        X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=0)

        #print(X_test.shape)
        #print(y_test.shape)
        """
        We have done normalization and standardization but haven't got any differences in accurarcies .So we have removed these..
        #_________________________________________________NORMALIZATION_____________________________________________________________________________________
        from sklearn.preprocessing import Normalizer
        scaler=Normalizer().fit(x)
        rescaledx=scaler.transform(x)
        #print(rescaledx)

        #_________________________________________________STANDARDIZATION________________________________________________________________________________
        from sklearn import preprocessing
        names=data.columns
        scaler=preprocessing.StandardScaler()
        scaled_data=scaler.fit_transform(data)
        scaled_data=pd.DataFrame(scaled_data,columns=names)
        """
        #_________________________________________________RANDOM_FOREST__________________________________________________________________________________________
        #Among all these three random forest techniques the highest accuracy of 68.31683168316832

        from sklearn.ensemble import RandomForestClassifier
        model5=RandomForestClassifier(n_estimators=200)                          
        model5.fit(X_train,y_train)

        from sklearn.metrics import accuracy_score


        y_pred_random_forest=model5.predict(X_test)
        print("Random_forest accuracy:",accuracy_score(y_test,y_pred_random_forest)*100)

        modelrand=RandomForestClassifier(max_depth=5,min_samples_split=3,min_samples_leaf=1)
        modelrand.fit(X_train,y_train)
        y_pred_random_forest=modelrand.predict(X_test)
        print("Random_forest accuracy_leaf:",accuracy_score(y_test,y_pred_random_forest)*100)

        modelrand1=RandomForestClassifier(max_features=10)
        modelrand1=RandomForestClassifier(max_features=.3)
        modelrand1.fit(X_train,y_train)
        y_pred_random_forest=modelrand1.predict(X_test)

        print("Random_forest accuracy_features:",accuracy_score(y_test,y_pred_random_forest)*100)

        #________________________________________________LOGISTIC_REGRESSION_____________________________________________________________________________
        #The maximum accuracy we got is ...    67.32673267326733

        from sklearn.linear_model import LogisticRegression
        model_LOGI=LogisticRegression()
        model_LOGI.fit(X_train,y_train)
        y_pred=model_LOGI.predict(X_test)
        from sklearn.metrics import accuracy_score
        print("acciuracy LOGISTIC:",accuracy_score(y_test,y_pred)*100)


        #_________________________________________________________SVM_____________________________________________________________________-
        #This algorithm gave the maximum accuracy!!
        #The maximum accuracy we got is ...    69.3069306930693
        #So  by using SVM we got better results...
        
        from sklearn.svm import SVC
        model_svm=SVC(kernel="linear")
        model_svm.fit(X_train,y_train)
        y_pred_svm=model_svm.predict(X_test)

        y_pred1_svm=model_svm.predict([[gender,Age,Music,Movies,Internet,Shopping,loneliness]])
        print(y_pred1_svm)

        if(y_pred1_svm ==1):
            print("Not at all Interactive")
            return "Not at all Interactive"
        elif(y_pred1_svm ==2):
            print("Some what Interactive")
            return "Not at all Interactive"
        elif(y_pred1_svm ==3):
            print("Interactive")
            return "Not at all Interactive"
        elif(y_pred1_svm ==4):
            print("fine relation")
            return "Not at all Interactive"
        elif(y_pred1_svm ==5):
            print("Very Interactive")
            return "Not at all Interactive"
         
        from sklearn.metrics import accuracy_score
        print("svm accuracy:",accuracy_score(y_test,y_pred_svm)*100)


from flask import *
app=Flask(__name__)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template("index.html")


@app.route('/insert',methods=['GET','POST'])
def insert():
    gender = request.form['Gender']
    Age = request.form['Age']
    Music = request.form['Music']
    Movies = request.form['Movies']
    Internet = request.form['Internet']
    Shopping = request.form['Shopping']
    loneliness = request.form['loneliness']
    data=func(gender,Age,Music,Movies,Internet,Shopping,loneliness)
    
    return data
    
    
if __name__ =="__main__":
    app.run(debug=True)
